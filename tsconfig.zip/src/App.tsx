import React, { useState, useRef, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import BirthdayContent from './components/BirthdayContent';
import './App.scss';

const App: React.FC = () => {
  const [unlocked, setUnlocked] = useState(false);
  const [currentCaption, setCurrentCaption] = useState(0);
  const [showMainContent, setShowMainContent] = useState(false);
  const [showIntro, setShowIntro] = useState(true);
  const [showHeart, setShowHeart] = useState(false);
  
  const heartRef = useRef<HTMLDivElement>(null);

  const captions = [
    "Hey Mohini...",
    "Happy 19th Birthday! 🎂",
    "A magical surprise awaits you...",
    "From someone special... 💖"
  ];

  // Initial animation sequence
  useEffect(() => {
    const timer1 = setTimeout(() => {
      setCurrentCaption(1);
    }, 3000);

    const timer2 = setTimeout(() => {
      setCurrentCaption(2);
    }, 6000);

    const timer3 = setTimeout(() => {
      setCurrentCaption(3);
    }, 9000);

    const timer4 = setTimeout(() => {
      setShowHeart(true);
    }, 12000);

    const timer5 = setTimeout(() => {
      setShowIntro(false);
      setShowMainContent(true);
    }, 15000);

    return () => {
      clearTimeout(timer1);
      clearTimeout(timer2);
      clearTimeout(timer3);
      clearTimeout(timer4);
      clearTimeout(timer5);
    };
  }, []);

  return (
    <div className="app">
      <AnimatePresence mode="wait">
        {showIntro && (
          <motion.div 
            className="intro-animation"
            initial={{ backgroundColor: '#000' }}
            exit={{ opacity: 0 }}
          >
            <motion.div
              className="intro-text"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 2 }}
            >
              <motion.h1
                key={currentCaption}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 1.5 }}
                className="welcome-text"
              >
                {captions[currentCaption]}
              </motion.h1>
            </motion.div>
            
            {showHeart && (
              <motion.div 
                className="intro-heart"
                initial={{ opacity: 0, scale: 0 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 1 }}
                ref={heartRef}
              >
                <div className="heart"></div>
              </motion.div>
            )}
          </motion.div>
        )}

        {showMainContent && !unlocked && (
          <motion.div 
            className="main-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <div className="glass-card">
              <motion.div
                className="card-content"
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 1 }}
              >
                <h2 className="card-title">Ready for your surprise?</h2>
                <div className="heart-container">
                  <div className="heart"></div>
                  <motion.button
                    className="unlock-button"
                    onClick={() => setUnlocked(true)}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    Unlock My Surprise
                  </motion.button>
                </div>
              </motion.div>
            </div>
          </motion.div>
        )}

        {unlocked && (
          <motion.div
            className="birthday-content"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1 }}
          >
            <BirthdayContent />
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

export default App;
