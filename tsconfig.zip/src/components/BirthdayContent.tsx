import React, { useState } from 'react';
import { motion } from 'framer-motion';
import './BirthdayContent.scss';

const BirthdayContent: React.FC = () => {
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [showLetter, setShowLetter] = useState(false);

  const images = [
    '/photos/IMG-20250127-WA0002.jpg',
    '/photos/IMG-20250127-WA0003.jpg',
    '/photos/IMG-20250127-WA0004.jpg',
    '/photos/IMG-20250127-WA0005.jpg',
    '/photos/IMG-20250127-WA0006.jpg',
    '/photos/IMG-20250127-WA0007.jpg',
    '/photos/IMG-20250127-WA0008.jpg',
    '/photos/IMG-20250127-WA0009.jpg',
    '/photos/IMG-20250127-WA0010.jpg',
    '/photos/IMG-20250127-WA0011.jpg',
    '/photos/IMG-20250127-WA0012.jpg',
    '/photos/IMG-20250127-WA0013.jpg',
    '/photos/IMG_20250127_153240_926.jpg',
    '/photos/IMG_20250127_153242_270.jpg',
    '/photos/IMG_20250127_153243_880.jpg',
    '/photos/IMG_20250127_153245_051.jpg',
    '/photos/IMG_20250127_153246_478.jpg',
    '/photos/IMG_20250127_153247_811.jpg',
    '/photos/IMG_20250127_153249_171.jpg',
    '/photos/IMG_20250127_153250_376.jpg',
    '/photos/IMG_20250203_152711_782.jpg',
    '/photos/IMG_20250203_152714_304.jpg',
    '/photos/IMG_20250203_152718_378.jpg',
    '/photos/IMG_20250203_152719_928.jpg',
    '/photos/IMG_20250204_203239_201.jpg',
    '/photos/IMG_20250302_215110_226.jpg',
    '/photos/IMG_20250331_195452_137.jpg'
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1
    }
  };

  return (
    <motion.div
      className="birthday-container"
      variants={containerVariants}
      initial="hidden"
      animate="visible"
    >
      <motion.div className="birthday-header" variants={itemVariants}>
        <h1 className="birthday-title">Happy 19th Birthday, Mohini! 🎉</h1>
        <div className="sparkles"></div>
      </motion.div>

      <motion.div 
        className="wish-text"
        variants={itemVariants}
      >
        <p className="highlight-text">
          To my dearest Mohini,
        </p>
        <p>
          As you turn 19 today, I want to take a moment to celebrate not just your birthday, 
          but the incredible person you are. Your presence in my life has been nothing short 
          of magical – like a bright star that lights up even the darkest nights.
        </p>
        <p>
          Your smile has this amazing power to make everything better, and your laughter 
          is the sweetest melody I've ever heard. The way you care for others, your 
          determination to chase your dreams, and your beautiful heart make you truly special.
        </p>
        <motion.button
          className="special-button"
          onClick={() => setShowLetter(true)}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          Read My Special Letter to You ❤️
        </motion.button>
      </motion.div>

      {showLetter && (
        <motion.div 
          className="letter-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <div className="letter-content">
            <h3>My Dearest Mohini,</h3>
            <p>
              As you step into your 19th year, I want you to know how much you mean to me. 
              Every moment with you feels like a blessing, and every smile you share makes my world brighter.
            </p>
            <p>
              You have this incredible ability to make everyone around you feel special. 
              Your kindness knows no bounds, your strength inspires me, and your determination 
              to achieve your goals makes me proud every single day.
            </p>
            <p>
              I wish for this year to bring you everything your heart desires:
            </p>
            <ul>
              <li>Success in every path you choose</li>
              <li>Happiness that knows no bounds</li>
              <li>Adventures that make your heart soar</li>
              <li>Dreams that turn into beautiful realities</li>
              <li>Love that grows stronger each day</li>
            </ul>
            <p>
              Remember, you are precious, you are loved, and you deserve all the happiness in the world.
              Thank you for being the amazing person you are.
            </p>
            <p className="signature">Forever Yours,<br/>Adrish ❤️</p>
            <motion.button
              className="close-button"
              onClick={() => setShowLetter(false)}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              Close Letter
            </motion.button>
          </div>
        </motion.div>
      )}

      <motion.div 
        className="memories-section"
        variants={itemVariants}
      >
        <h2 className="section-title">Our Beautiful Memories 💖</h2>
        <div className="photo-gallery">
          {images.map((image, index) => (
            <motion.div
              key={index}
              className="photo-container"
              variants={itemVariants}
              whileHover={{ 
                scale: 1.05,
                transition: { duration: 0.3 }
              }}
              onClick={() => setSelectedImage(image)}
            >
              <div className="photo-frame">
                <img src={image} alt={`Mohini ${index + 1}`} loading="lazy" />
              </div>
              <div className="photo-overlay">
                <span>Memory #{index + 1}</span>
              </div>
            </motion.div>
          ))}
        </div>
      </motion.div>

      {selectedImage && (
        <motion.div 
          className="image-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          onClick={() => setSelectedImage(null)}
        >
          <motion.img
            src={selectedImage}
            alt="Full size"
            initial={{ scale: 0.5 }}
            animate={{ scale: 1 }}
            transition={{ type: "spring", damping: 15 }}
          />
          <button className="close-button" onClick={() => setSelectedImage(null)}>
            Close
          </button>
        </motion.div>
      )}

      <motion.div 
        className="final-wish"
        variants={itemVariants}
      >
        <h2>Wishing You the Most Amazing Year Ahead! 🌟</h2>
        <p>
          May your 19th year be filled with endless joy, exciting adventures, 
          and beautiful moments that become cherished memories. You deserve 
          nothing but the best, my dear Mohini!
        </p>
        <div className="heart-animation">
          <div className="heart"></div>
        </div>
      </motion.div>
    </motion.div>
  );
};

export default BirthdayContent; 